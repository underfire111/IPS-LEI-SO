#if !defined(UTILS_H)
# define UTILS_H

char	**ft_split(char const *s, char c);

#endif // UTILS_H
