#include "struct.h"

#include <fcntl.h>
#include <semaphore.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

void	proj(pt_info info, pt_items items, pt_bag bag)
{
	int	*	pids;
	int	*	result;
	sem_t *	update;

	sem_unlink("update");
	update = sem_open("update", O_CREAT, 0644, 1);
	result = (int *)mmap(NULL, sizeof(int), PROT_READ |
		PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
	*result = 0;
	pids = (int *)malloc(sizeof(int) * info->num_processes);
	for (int i = 0; i < info->num_processes; i++)
	{
		pids[i] = fork();
		if (pids[i] == 0)
			pick_best_result(items, bag, update, result);
	}
	sem_close(update);
	sleep(info->time_limit);
	kill_all(pids, info->num_processes);
	printf("The best result found was: %d\n", *result);
}
